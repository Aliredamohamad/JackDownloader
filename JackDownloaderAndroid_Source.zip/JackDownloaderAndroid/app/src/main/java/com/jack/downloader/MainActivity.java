package com.jack.downloader;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.yausername.youtubedl_android.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.youtubedl_android.mapper.VideoInfo;

import kotlin.Unit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int STORAGE_REQUEST = 3001;
    private static final Pattern LINK_PATTERN = Pattern.compile("https?://[^\\s<>\"']+", Pattern.CASE_INSENSITIVE);
    private static final String[] FORMAT_LABELS = {
            "MP4 • فيديو", "MKV • فيديو", "WEBM • فيديو", "MOV • فيديو",
            "MP3 • صوت", "M4A • صوت", "WAV • صوت", "FLAC • صوت", "OPUS • صوت"
    };
    private static final String[] EXTENSIONS = {"mp4", "mkv", "webm", "mov", "mp3", "m4a", "wav", "flac", "opus"};
    private static final String[] QUALITY_LABELS = {
            "أفضل جودة متاحة", "4K • 2160p", "2K • 1440p", "Full HD • 1080p",
            "HD • 720p", "480p", "360p", "240p"
    };
    private static final int[] QUALITY_LIMITS = {0, 2160, 1440, 1080, 720, 480, 360, 240};

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private volatile boolean ready = false;
    private volatile String activeProcessId;
    private long lastUiUpdate = 0;

    private EditText urlInput;
    private Spinner formatSpinner;
    private Spinner qualitySpinner;
    private TextView titleText;
    private TextView statusText;
    private ProgressBar progressBar;
    private Button analyzeButton;
    private Button downloadButton;
    private Button cancelButton;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        urlInput = findViewById(R.id.editUrl);
        formatSpinner = findViewById(R.id.spinnerFormat);
        qualitySpinner = findViewById(R.id.spinnerQuality);
        titleText = findViewById(R.id.textTitle);
        statusText = findViewById(R.id.textStatus);
        progressBar = findViewById(R.id.progressDownload);
        analyzeButton = findViewById(R.id.btnAnalyze);
        downloadButton = findViewById(R.id.btnDownload);
        cancelButton = findViewById(R.id.btnCancel);

        configureSpinner(formatSpinner, FORMAT_LABELS);
        configureSpinner(qualitySpinner, QUALITY_LABELS);
        downloadButton.setEnabled(false);
        analyzeButton.setEnabled(false);
        findViewById(R.id.btnPaste).setOnClickListener(v -> pasteLink());
        analyzeButton.setOnClickListener(v -> analyze());
        downloadButton.setOnClickListener(v -> download());
        cancelButton.setOnClickListener(v -> cancelDownload());
        findViewById(R.id.btnOpenDownloads).setOnClickListener(v -> openDownloads());

        receiveLink(getIntent());
        worker.execute(() -> {
            try {
                YoutubeDL.getInstance().init(getApplicationContext());
                FFmpeg.getInstance().init(getApplicationContext());
                ready = true;
                ui(() -> {
                    statusText.setText("المحرك جاهز ✓");
                    downloadButton.setEnabled(true);
                    analyzeButton.setEnabled(true);
                });
            } catch (Exception e) {
                ui(() -> statusText.setText("تعذّر تهيئة محرك التنزيل: " + safeMessage(e)));
            }
        });
    }

    private void configureSpinner(Spinner spinner, String[] options) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, options);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        spinner.setAdapter(adapter);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        receiveLink(intent);
    }

    private void receiveLink(Intent intent) {
        if (intent == null) return;
        String input = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            input = intent.getStringExtra(Intent.EXTRA_TEXT);
        } else if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            input = intent.getData().toString();
        }
        if (!TextUtils.isEmpty(input)) {
            String link = extractUrl(input);
            if (link != null) urlInput.setText(link);
        }
    }

    private void pasteLink() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) {
            toast("الحافظة فارغة");
            return;
        }
        ClipData clip = clipboard.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return;
        CharSequence value = clip.getItemAt(0).coerceToText(this);
        String link = extractUrl(value == null ? "" : value.toString());
        if (link == null) {
            toast("لم أجد رابطاً صالحاً");
        } else {
            urlInput.setText(link);
            statusText.setText("تم لصق الرابط");
        }
    }

    private static String extractUrl(String value) {
        if (value == null) return null;
        Matcher matcher = LINK_PATTERN.matcher(value.trim());
        if (!matcher.find()) return null;
        String link = matcher.group();
        while (link.endsWith(".") || link.endsWith(",") || link.endsWith(")") || link.endsWith("،")) {
            link = link.substring(0, link.length() - 1);
        }
        Uri uri = Uri.parse(link);
        if (TextUtils.isEmpty(uri.getHost())) return null;
        return link;
    }

    private void analyze() {
        String link = extractUrl(urlInput.getText().toString());
        if (link == null) { toast("ضع رابطاً يبدأ بـ https:// أو http://"); return; }
        if (!ready) { toast("المحرك غير جاهز"); return; }
        if (!busy.compareAndSet(false, true)) { toast("هناك عملية جارية"); return; }
        setWorking(true, false);
        statusText.setText("جارٍ تحليل الرابط...");
        progressBar.setProgress(0);
        worker.execute(() -> {
            try {
                VideoInfo info = YoutubeDL.getInstance().getInfo(link);
                String title = info.getTitle();
                ui(() -> {
                    titleText.setText(TextUtils.isEmpty(title) ? "تم التعرف على المحتوى" : title);
                    statusText.setText("الرابط مدعوم؛ اختر الصيغة والجودة ثم اضغط تنزيل");
                });
            } catch (Exception e) {
                ui(() -> statusText.setText("لم ينجح التحليل: " + safeMessage(e)));
            } finally {
                busy.set(false);
                ui(() -> setWorking(false, false));
            }
        });
    }

    private void download() {
        String link = extractUrl(urlInput.getText().toString());
        if (link == null) { toast("الصق رابط فيديو أو صوت أولاً"); return; }
        if (!ready) { toast("محرك التنزيل غير جاهز"); return; }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
            return;
        }
        if (!busy.compareAndSet(false, true)) { toast("هناك عملية جارية"); return; }
        int formatIndex = formatSpinner.getSelectedItemPosition();
        int qualityIndex = qualitySpinner.getSelectedItemPosition();
        cancelled.set(false);
        progressBar.setProgress(0);
        setWorking(true, true);
        statusText.setText("جارٍ التحضير للتنزيل...");
        worker.execute(() -> downloadInBackground(link, EXTENSIONS[formatIndex], QUALITY_LIMITS[qualityIndex]));
    }

    private void downloadInBackground(String url, String extension, int maxHeight) {
        File staging = null;
        String processId = "jack_" + UUID.randomUUID();
        activeProcessId = processId;
        try {
            File parent = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (parent == null) parent = getFilesDir();
            staging = new File(parent, processId);
            if (!staging.mkdirs() && !staging.isDirectory()) throw new IOException("تعذر إنشاء مجلد مؤقت");
            YoutubeDLRequest request = new YoutubeDLRequest(url);
            request.addOption("--no-playlist");
            request.addOption("--no-mtime");
            request.addOption("--no-overwrites");
            request.addOption("-o", new File(staging, "%(title).100B [%(id)s].%(ext)s").getAbsolutePath());

            boolean audio = isAudio(extension);
            if (audio) {
                request.addOption("-f", "bestaudio/best");
                request.addOption("-x");
                request.addOption("--audio-format", extension);
                request.addOption("--audio-quality", "0");
            } else {
                String selection = maxHeight == 0 ? "bv*+ba/b" :
                        "bv*[height<=" + maxHeight + "]+ba/b[height<=" + maxHeight + "]";
                request.addOption("-f", selection);
                if ("mkv".equals(extension)) {
                    request.addOption("--merge-output-format", "mkv");
                    request.addOption("--remux-video", "mkv");
                } else {
                    request.addOption("--merge-output-format", extension);
                    request.addOption("--recode-video", extension);
                }
            }
            lastUiUpdate = 0;
            YoutubeDL.getInstance().execute(request, processId, (progress, etaSeconds, logLine) -> {
                long now = SystemClock.elapsedRealtime();
                if (now - lastUiUpdate > 300 || progress >= 100) {
                    lastUiUpdate = now;
                    int percentage = Math.max(0, Math.min(100, Math.round(progress)));
                    ui(() -> {
                        progressBar.setProgress(percentage);
                        statusText.setText(String.format(Locale.ROOT,
                                "التنزيل %d%% • الوقت المتبقي تقريباً %d ثانية", percentage,
                                Math.max(0, etaSeconds)));
                    });
                }
                return Unit.INSTANCE;
            });
            if (cancelled.get()) return;

            File[] files = staging.listFiles((dir, name) -> !name.endsWith(".part")
                    && !name.endsWith(".ytdl") && !name.endsWith(".temp"));
            if (files == null || files.length == 0) throw new IOException("لم ينتج ملف من الرابط");
            ui(() -> statusText.setText("اكتمل التنزيل؛ جارٍ حفظ الملف في التنزيلات..."));
            int saved = 0;
            for (File file : files) {
                if (cancelled.get()) return;
                if (file.isFile() && file.length() > 0) {
                    saveToPublicDownloads(file);
                    saved++;
                }
            }
            if (saved == 0) throw new IOException("لم يُعثر على ملف نهائي صالح");
            final int count = saved;
            ui(() -> {
                progressBar.setProgress(100);
                statusText.setText("تم حفظ " + count + " ملف في Download/Jack Downloader ✓");
                toast("اكتمل التنزيل");
            });
        } catch (Exception e) {
            if (!cancelled.get()) ui(() -> statusText.setText("فشل التنزيل: " + safeMessage(e)));
        } finally {
            activeProcessId = null;
            if (staging != null) deleteTree(staging);
            busy.set(false);
            ui(() -> {
                if (cancelled.get()) statusText.setText("تم إلغاء التنزيل");
                setWorking(false, false);
            });
        }
    }

    private void saveToPublicDownloads(File source) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, source.getName());
            values.put(MediaStore.Downloads.MIME_TYPE, mimeFor(source.getName()));
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Jack Downloader");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (destination == null) throw new IOException("فشل إنشاء الملف في التنزيلات");
            boolean complete = false;
            try {
                try (InputStream in = new FileInputStream(source);
                     OutputStream out = getContentResolver().openOutputStream(destination)) {
                    if (out == null) throw new IOException("تعذر فتح الملف للحفظ");
                    byte[] chunk = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(chunk)) >= 0) {
                        if (cancelled.get()) throw new IOException("تم الإلغاء");
                        out.write(chunk, 0, n);
                    }
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(destination, values, null, null);
                complete = true;
            } finally {
                if (!complete) getContentResolver().delete(destination, null, null);
            }
        } else {
            File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Jack Downloader");
            if (!folder.exists() && !folder.mkdirs()) throw new IOException("تعذر إنشاء مجلد التنزيلات");
            File target = uniqueFile(folder, source.getName());
            try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(target)) {
                byte[] chunk = new byte[64 * 1024];
                int n;
                while ((n = in.read(chunk)) >= 0) {
                    if (cancelled.get()) throw new IOException("تم الإلغاء");
                    out.write(chunk, 0, n);
                }
            } catch (IOException e) {
                // Do not leave a partially copied file behind.
                //noinspection ResultOfMethodCallIgnored
                target.delete();
                throw e;
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(target)));
        }
    }

    private static File uniqueFile(File folder, String name) {
        File candidate = new File(folder, name);
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String extension = dot > 0 ? name.substring(dot) : "";
        int suffix = 1;
        while (candidate.exists()) candidate = new File(folder, base + " (" + suffix++ + ")" + extension);
        return candidate;
    }

    private static String mimeFor(String name) {
        String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        switch (ext) {
            case "mp4": return "video/mp4";
            case "mkv": return "video/x-matroska";
            case "webm": return "video/webm";
            case "mov": return "video/quicktime";
            case "mp3": return "audio/mpeg";
            case "m4a": return "audio/mp4";
            case "wav": return "audio/wav";
            case "flac": return "audio/flac";
            case "opus": return "audio/opus";
            default: return "application/octet-stream";
        }
    }

    private static boolean isAudio(String extension) {
        return "mp3".equals(extension) || "m4a".equals(extension)
                || "wav".equals(extension) || "flac".equals(extension) || "opus".equals(extension);
    }

    private void cancelDownload() {
        if (!busy.get() || activeProcessId == null) return;
        cancelled.set(true);
        statusText.setText("جارٍ إلغاء العملية...");
        final String process = activeProcessId;
        new Thread(() -> {
            try { YoutubeDL.getInstance().destroyProcessById(process); }
            catch (Exception ignored) { }
        }, "jack-cancel").start();
    }

    private void openDownloads() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivity(Intent.createChooser(intent, "ملفات Jack Downloader داخل التنزيلات"));
        } catch (Exception e) {
            toast("افتح تطبيق الملفات ثم Download/Jack Downloader");
        }
    }

    private void setWorking(boolean working, boolean downloading) {
        analyzeButton.setEnabled(ready && !working);
        downloadButton.setEnabled(ready && !working);
        cancelButton.setEnabled(working && downloading);
    }

    private static void deleteTree(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private static String safeMessage(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.isEmpty()) return ex.getClass().getSimpleName();
        return message.length() > 220 ? message.substring(0, 220) + "..." : message;
    }

    private void ui(Runnable task) { runOnUiThread(task); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == STORAGE_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) download();
            else toast("يحتاج التطبيق إذن التخزين على أندرويد 9 وما قبله");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Downloads should run only while the app is open in this MVP.
        if (busy.get() && activeProcessId != null) {
            cancelled.set(true);
            try { YoutubeDL.getInstance().destroyProcessById(activeProcessId); }
            catch (Exception ignored) { }
        }
        worker.shutdown();
    }
}
